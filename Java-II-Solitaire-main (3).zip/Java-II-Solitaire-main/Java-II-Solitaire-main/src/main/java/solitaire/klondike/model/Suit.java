package solitaire.klondike.model;

public enum Suit {
    SPADES, HEARTS, DIAMONDS, CLUBS
}
