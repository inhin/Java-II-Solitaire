package solitaire.core;

public enum Theme {
    CLASSIC,
    OCEAN,
    DARK
}

