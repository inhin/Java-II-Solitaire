package directorysearch;

//***************************************************
//
// File for Directory Search Assignment
//
// File name: DirectoryChecksum.java
//
//Recursive Directory Search method
//     from: http://stackoverflow.com/questions/2534632/list-all-files-from-a-directory-recursively-with-java
//
// Purpose: This assignment focuses on
//          implementing file I/O.
//
// Name: Jenascia Drew
// Course: CPT-237
// Section: W38
// Semester: SPRING
// Date: 12/03/2025
//
//***************************************************

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class DirectoryChecksum {

    private static long checksumTotal = 0;

    public static void main(String[] args) {

        String targetDirectory = ("C:\\Users\\drew3\\OneDrive\\Documents\\CPT-237");

        System.out.println("Starting count...");
        countChecksum(targetDirectory);
        System.out.println("Count Complete!");
        System.out.println("Checksum Total: " + checksumTotal);
    }

    public static void countChecksum(String tDir){

        // tDir is the target directory path string
        File directory = new File(tDir);

        // Directory validation check
        if (!directory.exists() || !directory.isDirectory() || !directory.canRead()) {
            System.err.println("Error: Cannot access directory: " + tDir);
            return;
        }

        //
        File[] faFiles = new File(tDir).listFiles();

        for (File file: faFiles){
            if (file.isFile() && file.canRead()) {
                // Read the file and add to the total
                addToChecksum(file);
            } else if (file.isDirectory()) {
                // Sub directories
                countChecksum(file.getAbsolutePath());
            }
        }
    }

    // Reads all files and adds them to the total
    private static void addToChecksum(File file) {
        try (InputStream isValid = new FileInputStream(file)) {
            int readBytes;

            // Loop for reading the bytes
            while ((readBytes = isValid.read()) != -1) {
                // Add to total
                checksumTotal += readBytes;
            }
        } catch (IOException e) {
            // continues reading the files even if one file causes an error
            System.err.println("I/O Error reading file: " +
                    file.getAbsolutePath() + " - " +
                    e.getMessage());
        }
    }
}

